import { Iconfig } from './types';

export const config: Iconfig = {
  port: 8082,
  production: false,
  database: {
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'docs',
  },
  domain: 'localhost',
  mode: 'development',
  ALLOWED_DOMAINS: ['http://localhost:5173'],
  secret: '<random values>',
};
