import { hashSync } from 'bcrypt';

console.log(hashSync('Password', 1));
